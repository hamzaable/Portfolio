self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "39994e6e32f7d376263f813b0109cce2",
    "url": "/index.html"
  },
  {
    "revision": "97f933b937d66fdf8e99",
    "url": "/static/css/main.5541b4f0.chunk.css"
  },
  {
    "revision": "f764ff14e3be4d2f18fe",
    "url": "/static/js/2.dee34505.chunk.js"
  },
  {
    "revision": "aa4100970f46d7e0ec2af84de3f2740b",
    "url": "/static/js/2.dee34505.chunk.js.LICENSE.txt"
  },
  {
    "revision": "97f933b937d66fdf8e99",
    "url": "/static/js/main.61296107.chunk.js"
  },
  {
    "revision": "4f2b1704eab49d50853b",
    "url": "/static/js/runtime-main.19ccc7f6.js"
  },
  {
    "revision": "331ec49c0d78e469c42c1d814dd45838",
    "url": "/static/media/Avenir-Book.331ec49c.ttf"
  },
  {
    "revision": "901497541657a2f24e42848bcf7fad52",
    "url": "/static/media/Avenir-Heavy.90149754.ttf"
  },
  {
    "revision": "2090551770be22b09600a40b0b4673b7",
    "url": "/static/media/Avenir-Medium.20905517.ttf"
  },
  {
    "revision": "7fc613aa32db9b0e37135cb29fae858d",
    "url": "/static/media/Avenir-MediumOblique.7fc613aa.ttf"
  },
  {
    "revision": "e1f3b9cb93cd6e44dad626af0ab9abd9",
    "url": "/static/media/asterisk-solid.e1f3b9cb.svg"
  },
  {
    "revision": "02df545e8ae6626054bd4b89c594be27",
    "url": "/static/media/background-md.02df545e.svg"
  },
  {
    "revision": "d5d25e5c48150f57e52f06b6f7c6513a",
    "url": "/static/media/background-sm.d5d25e5c.svg"
  },
  {
    "revision": "a88aca4da8519555b373964d8a3199b5",
    "url": "/static/media/footer-md.a88aca4d.svg"
  },
  {
    "revision": "c70b666c5e18ca598860460df8379421",
    "url": "/static/media/footer-sm.c70b666c.svg"
  },
  {
    "revision": "d20b45837fe793ac76b8271696d12d13",
    "url": "/static/media/undraw_Beer_celebration_cefj.d20b4583.svg"
  },
  {
    "revision": "b4ef6ec445ac4cfa4ec05ff5125f7feb",
    "url": "/static/media/undraw_JavaScript_frameworks_8qpc.b4ef6ec4.svg"
  },
  {
    "revision": "edfd228963e4b82a797cfcff6ea23e42",
    "url": "/static/media/undraw_To_the_stars_qhyy.edfd2289.svg"
  },
  {
    "revision": "2aa9d48fb0f63733d78b4e637f5102a6",
    "url": "/static/media/undraw_calendar_dutt.2aa9d48f.svg"
  },
  {
    "revision": "62754a97bd86f1f7d5869a8fde33471a",
    "url": "/static/media/undraw_code_review_l1q9.62754a97.svg"
  },
  {
    "revision": "02623b7c54a4ed5c74405345bc22961b",
    "url": "/static/media/undraw_confirmation_2uy0.02623b7c.svg"
  },
  {
    "revision": "59389695208d7454c6607bed51ed4316",
    "url": "/static/media/undraw_developer_activity_bv83.59389695.svg"
  },
  {
    "revision": "4cc8970ecb8e7495569be73840a43667",
    "url": "/static/media/undraw_futuristic_interface_4q3p.4cc8970e.svg"
  },
  {
    "revision": "3aaaa55cb40578802817dfb850459360",
    "url": "/static/media/undraw_portfolio_website_lidw.3aaaa55c.svg"
  },
  {
    "revision": "e56ab6de71d19f2fac0f12a7fadb588d",
    "url": "/static/media/undraw_react_y7wq.e56ab6de.svg"
  },
  {
    "revision": "e52e17043b4d2f8a5fdba2bff33812b6",
    "url": "/static/media/undraw_server_status_5pbv.e52e1704.svg"
  },
  {
    "revision": "dd2288fc6be04bcbf8fda8efc830ea0f",
    "url": "/static/media/undraw_setup_analytics_8qkl.dd2288fc.svg"
  },
  {
    "revision": "c072f08dade31e501af2a7d318ad6063",
    "url": "/static/media/undraw_static_website_0107.c072f08d.svg"
  },
  {
    "revision": "7600954ccde7873e2e33c2e4443ecb91",
    "url": "/static/media/undraw_tailwind_css_1egw.7600954c.svg"
  },
  {
    "revision": "30fbb50df40be2394f9663568ab87114",
    "url": "/static/media/undraw_time_management_30iu.30fbb50d.svg"
  },
  {
    "revision": "f7f12d8b700f6d8f96ca0c84a7a366e3",
    "url": "/static/media/undraw_web_developer_p3e5.f7f12d8b.svg"
  }
]);